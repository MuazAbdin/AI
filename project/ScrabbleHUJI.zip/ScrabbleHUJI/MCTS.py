import time
import random
import math


class MonteCarloTreeSearch:
    def __init__(self, board):
        self.board = board
        self.states = []

    def update(self, state):
        self.states.append(state)