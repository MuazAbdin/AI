from typing import Callable

from board import Board, Play

Strategy = Callable[[Board, str], Play]


class Player:
    def __init__(self, name: str, strategy: Strategy = None):
        self.name = name
        self.score = 0
        self.rack = ''
        self.strategy = strategy

    def is_human(self):
        return self.strategy is not None
