

def Word(w: str) -> str: return w.strip().upper()

def is_word(word: str) -> bool:
    """ Is this a legal word in the dictionary? """
    return word.upper() in DICTIONARY